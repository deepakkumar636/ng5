import { Component } from '@angular/core';
import { filter } from 'rxjs/operator/filter';

@Component ({
    selector : 'list-employee',
    templateUrl : './employeeList.component.html',
    styleUrls : ['./employeeList.component.css']   
})
export class employeeListComponent{
    employees :any[];

    constructor(){
    this. employees  = [
        { code: 'emp101', name: 'Deepak', gender: 'Male', anualsalary: '5500', dateOfBirth:'10/12/1986'},
        { code: 'emp102', name: 'Neeraj', gender: 'Male', anualsalary: '5700.95', dateOfBirth:'06/06/1988'},
        { code: 'emp103', name: 'Sonu', gender: 'Male', anualsalary: '6500', dateOfBirth:'06/06/1988'},
        { code: 'emp104', name: 'Aman', gender: 'Male', anualsalary: '6700', dateOfBirth:'06/06/1988'},
        { code: 'emp105', name: 'Prachi', gender: 'FeMale', anualsalary: '5500.628', dateOfBirth:'06/06/1988'},
        { code: 'emp106', name: 'Preeti', gender: 'FeMale', anualsalary: '5500.628', dateOfBirth:'06/06/1988'}
        
        ];
    }
    getTotalEmployeesCount():number {
        return this.employees.length;
    }
    getTotalMaleEmployeesCount():number {
        return this.employees.filter(e => e.gender ==="Male").length;
    }
    getTotalFemaleEmployeesCount():number {
        return this.employees.filter(e => e.gender ==="FeMale").length;
    }
}