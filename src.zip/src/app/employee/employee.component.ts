import  { Component } from '@angular/core';

@Component({

    selector : 'my-employee',
    templateUrl : './employee.component.html',
    styleUrls : ['./employee.component.css']
})
export class EmployeeComponent{
    firstName : string = 'Deepak';
    lastName : string = 'Pandey';
    gender : string = 'Male';
    age : number = 20;
}