import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl : './app.component.html',
  styleUrls : ['./app.component.css']
})
export class AppComponent {
  pageHeader : string = "Employee Details";
  firstName : string = 'Deepak';
  lastName : string = 'Pandey';

  getFullName(){
    return this.firstName + ' ' + this.lastName;
  }
}
